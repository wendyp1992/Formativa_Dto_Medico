<?php
/* @var $this yii\web\View */

$this->title = 'Home';
?>
<div class="site-index">
    <div class="jumbotron">
        <br> <br><br><br><br>
        <h1>DEPARTAMENTO MÉDICO</h1>
        <p>Escritorio </p>

    </div>
    <div class="body-content">
    </div>
</div>
