<?php

/* @var $this yii\web\View */

$this->title = 'Home';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>PUCESE</h1>

        <p class="lead">App Frontend</p>

  
    </div>

    <div class="body-content">

    </div>
</div>
